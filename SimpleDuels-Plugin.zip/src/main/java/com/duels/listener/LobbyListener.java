package com.duels.listener;

import com.duels.DuelsPlugin;
import com.duels.gui.DuelGUI;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class LobbyListener implements Listener {
    private final DuelsPlugin plugin;

    public LobbyListener(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        plugin.getDuelManager().sendToLobby(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.getDuelManager().leaveQueue(e.getPlayer());
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (plugin.getDuelManager().isDuelSword(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInvClick(InventoryClickEvent e) {
        if (plugin.getDuelManager().isDuelSword(e.getCurrentItem()) || plugin.getDuelManager().isDuelSword(e.getCursor())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (plugin.getDuelManager().isDuelSword(item)) {
            e.setCancelled(true);
            Player player = e.getPlayer();
            if (!plugin.getDuelManager().isInMatch(player.getUniqueId())) {
                DuelGUI.open(plugin, player);
            }
        }
    }
}
