package com.duels.listener;

import com.duels.DuelsPlugin;
import com.duels.gui.AdminGUI;
import com.duels.gui.DuelGUI;
import com.duels.gui.LayoutEditorGUI;
import com.duels.manager.DuelManager;
import com.duels.model.ArenaMap;
import com.duels.model.DuelKit;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class GuiListener implements Listener {
    private final DuelsPlugin plugin;
    private final Set<UUID> creatingKit = new HashSet<>();

    public GuiListener(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player player)) return;
        String title = PlainTextComponentSerializer.plainText().serialize(e.getView().title());

        // 1. Меню /duel
        if (title.equals(DuelGUI.TITLE)) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            NamespacedKey key = new NamespacedKey(plugin, "kit_id");
            String kitId = clicked.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (kitId == null) return;

            DuelKit kit = plugin.getKitManager().getKit(kitId);
            if (kit == null) return;

            if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) {
                LayoutEditorGUI.open(plugin, player, kit);
            } else {
                player.closeInventory();
                plugin.getDuelManager().joinQueue(player, kit);
            }
            return;
        }

        // 2. Редактор раскладки
        if (title.startsWith(LayoutEditorGUI.PREFIX)) {
            String kitId = title.substring(LayoutEditorGUI.PREFIX.length());
            // Запрещаем кликать в собственный инвентарь игрока, чтобы нельзя было подложить/забрать вещи
            if (e.getClickedInventory() != e.getView().getTopInventory()) {
                e.setCancelled(true);
                return;
            }
            if (e.getSlot() >= 36) {
                e.setCancelled(true);
                if (e.getSlot() == 40) { // Кнопка сохранения
                    Inventory top = e.getView().getTopInventory();
                    ItemStack[] newLayout = new ItemStack[36];
                    for (int i = 0; i < 36; i++) {
                        newLayout[i] = top.getItem(i) != null ? top.getItem(i).clone() : null;
                    }
                    plugin.getLayoutManager().setLayout(player.getUniqueId(), kitId, newLayout);
                    player.closeInventory();
                    player.sendMessage("§aРаскладка для кита сохранена!");
                }
            }
            return;
        }

        // 3. Главное админ-меню
        if (title.equals(AdminGUI.MAIN_TITLE)) {
            e.setCancelled(true);
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;

            if (e.getSlot() == 49 && clicked.getType() == Material.EMERALD_BLOCK) {
                creatingKit.add(player.getUniqueId());
                player.closeInventory();
                player.sendMessage("§aНапишите в чат название нового кита (или 'отмена'):");
                return;
            }

            NamespacedKey key = new NamespacedKey(plugin, "admin_kit_id");
            String kitId = clicked.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
            if (kitId != null) {
                DuelKit kit = plugin.getKitManager().getKit(kitId);
                if (kit != null) {
                    AdminGUI.openEdit(plugin, player, kit);
                }
            }
            return;
        }

        // 4. Редактирование кита
        if (title.startsWith(AdminGUI.EDIT_PREFIX)) {
            e.setCancelled(true);
            String kitId = title.substring(AdminGUI.EDIT_PREFIX.length());
            DuelKit kit = plugin.getKitManager().getKit(kitId);
            if (kit == null) return;

            switch (e.getSlot()) {
                case 10 -> { // Смена иконки
                    ItemStack hand = player.getInventory().getItemInMainHand();
                    if (hand.getType() == Material.AIR) {
                        player.sendMessage("§cВозьмите нужный предмет в правую руку!");
                    } else {
                        kit.setIcon(hand.getType());
                        plugin.getKitManager().saveKits();
                        player.sendMessage("§aИконка кита изменена на " + hand.getType().name());
                        AdminGUI.openEdit(plugin, player, kit);
                    }
                }
                case 12 -> { // Вставить карту из WorldEdit
                    ArenaMap map = plugin.getMapManager().importFromWorldEdit(player);
                    if (map != null) {
                        kit.getMapIds().add(map.getId());
                        plugin.getKitManager().saveKits();
                        player.sendMessage("§aКарта успешно добавлена к киту §e" + kit.getDisplayName() + "§a!");
                        AdminGUI.openEdit(plugin, player, kit);
                    }
                }
                case 14 -> { // Обновить вещи
                    kit.setContents(DuelManager.cloneArray(player.getInventory().getStorageContents()));
                    kit.setArmor(DuelManager.cloneArray(player.getInventory().getArmorContents()));
                    kit.setOffhand(player.getInventory().getItemInOffHand().clone());
                    plugin.getKitManager().saveKits();
                    player.sendMessage("§aВещи кита обновлены из вашего инвентаря!");
                }
                case 16 -> { // Удалить кит
                    plugin.getKitManager().removeKit(kit.getId());
                    player.sendMessage("§cКит удалён.");
                    AdminGUI.openMain(plugin, player);
                }
                case 22 -> AdminGUI.openMain(plugin, player);
            }
        }
    }

    @EventHandler
    public void onChat(AsyncChatEvent e) {
        Player player = e.getPlayer();
        if (!creatingKit.remove(player.getUniqueId())) return;

        e.setCancelled(true);
        String name = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
        if (name.equalsIgnoreCase("отмена")) {
            player.sendMessage("§eСоздание кита отменено.");
            return;
        }

        String id = name.toLowerCase().replaceAll("[^a-zа-я0-9_]", "_");
        Bukkit.getScheduler().runTask(plugin, () -> {
            Material icon = player.getInventory().getItemInMainHand().getType();
            if (icon == Material.AIR) icon = Material.DIAMOND_SWORD;

            DuelKit kit = new DuelKit(
                    id,
                    name,
                    icon,
                    DuelManager.cloneArray(player.getInventory().getStorageContents()),
                    DuelManager.cloneArray(player.getInventory().getArmorContents()),
                    player.getInventory().getItemInOffHand().clone()
            );
            plugin.getKitManager().addKit(kit);
            player.sendMessage("§aКит §e" + name + " §aсоздан! Открываю его настройки...");
            AdminGUI.openEdit(plugin, player, kit);
        });
    }
}
