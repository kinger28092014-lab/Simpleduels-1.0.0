package com.duels.listener;

import com.duels.DuelsPlugin;
import com.duels.model.DuelMatch;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class DuelListener implements Listener {
    private final DuelsPlugin plugin;

    public DuelListener(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        DuelMatch match = plugin.getDuelManager().getMatch(e.getPlayer().getUniqueId());
        if (match != null && match.isStarting()) {
            if (e.getFrom().getX() != e.getTo().getX() || e.getFrom().getZ() != e.getTo().getZ()) {
                e.setTo(e.getFrom());
            }
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        DuelMatch match = plugin.getDuelManager().getMatch(p.getUniqueId());
        if (match == null) {
            // Защита от урона в лобби
            e.setCancelled(true);
        } else if (match.isStarting()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player dead = e.getEntity();
        DuelMatch match = plugin.getDuelManager().getMatch(dead.getUniqueId());
        if (match == null) return;

        e.getDrops().clear();
        e.setDroppedExp(0);
        e.deathMessage(null);

        dead.spigot().respawn();
        plugin.getDuelManager().endMatch(match, match.getOpponent(dead.getUniqueId()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        DuelMatch match = plugin.getDuelManager().getMatch(p.getUniqueId());
        if (match != null) {
            plugin.getDuelManager().endMatch(match, match.getOpponent(p.getUniqueId()));
        }
    }
}
