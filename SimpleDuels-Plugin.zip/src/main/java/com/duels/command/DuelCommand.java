package com.duels.command;

import com.duels.DuelsPlugin;
import com.duels.gui.DuelGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class DuelCommand implements CommandExecutor {
    private final DuelsPlugin plugin;

    public DuelCommand(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Только для игроков.");
            return true;
        }

        if (args.length > 0 && args[0].equalsIgnoreCase("setlobby")) {
            if (!player.hasPermission("duels.admin")) {
                player.sendMessage("§cНет прав.");
                return true;
            }
            plugin.setLobbyLocation(player.getLocation());
            player.sendMessage("§aТочка лобби дуэлей установлена!");
            return true;
        }

        if (plugin.getDuelManager().isInMatch(player.getUniqueId())) {
            player.sendMessage("§cНельзя открыть меню во время боя!");
            return true;
        }

        DuelGUI.open(plugin, player);
        return true;
    }
}
