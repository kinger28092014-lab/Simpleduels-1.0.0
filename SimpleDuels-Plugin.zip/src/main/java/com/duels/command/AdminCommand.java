package com.duels.command;

import com.duels.DuelsPlugin;
import com.duels.gui.AdminGUI;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AdminCommand implements CommandExecutor {
    private final DuelsPlugin plugin;

    public AdminCommand(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;
        if (!player.hasPermission("duels.admin")) {
            player.sendMessage("§cНет прав.");
            return true;
        }
        AdminGUI.openMain(plugin, player);
        return true;
    }
}
