package com.duels.model;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class DuelKit {
    private final String id;
    private String displayName;
    private Material icon;
    private ItemStack[] contents;
    private ItemStack[] armor;
    private ItemStack offhand;
    private final List<String> mapIds;

    public DuelKit(String id, String displayName, Material icon, ItemStack[] contents, ItemStack[] armor, ItemStack offhand) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon != null ? icon : Material.DIAMOND_SWORD;
        this.contents = contents;
        this.armor = armor;
        this.offhand = offhand;
        this.mapIds = new ArrayList<>();
    }

    public String getId() { return id; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public Material getIcon() { return icon; }
    public void setIcon(Material icon) { this.icon = icon; }
    public ItemStack[] getContents() { return contents; }
    public void setContents(ItemStack[] contents) { this.contents = contents; }
    public ItemStack[] getArmor() { return armor; }
    public void setArmor(ItemStack[] armor) { this.armor = armor; }
    public ItemStack getOffhand() { return offhand; }
    public void setOffhand(ItemStack offhand) { this.offhand = offhand; }
    public List<String> getMapIds() { return mapIds; }
}
