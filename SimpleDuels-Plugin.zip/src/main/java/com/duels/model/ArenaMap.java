package com.duels.model;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.util.Vector;

import java.util.Map;

public class ArenaMap {
    private final String id;
    private final int sizeX, sizeY, sizeZ;
    private final Map<String, String> blocks;
    private final Vector spawn1;
    private final Vector spawn2;

    public ArenaMap(String id, int sizeX, int sizeY, int sizeZ, Map<String, String> blocks, Vector spawn1, Vector spawn2) {
        this.id = id;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.blocks = blocks;
        this.spawn1 = spawn1;
        this.spawn2 = spawn2;
    }

    public String getId() { return id; }
    public int getSizeX() { return sizeX; }
    public int getSizeY() { return sizeY; }
    public int getSizeZ() { return sizeZ; }
    public Map<String, String> getBlocks() { return blocks; }
    public Vector getSpawn1() { return spawn1; }
    public Vector getSpawn2() { return spawn2; }

    public Location[] paste(Location origin) {
        World world = origin.getWorld();
        int ox = origin.getBlockX();
        int oy = origin.getBlockY();
        int oz = origin.getBlockZ();

        for (int x = 0; x <= sizeX; x++) {
            for (int y = 0; y <= sizeY; y++) {
                for (int z = 0; z <= sizeZ; z++) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setType(Material.AIR, false);
                }
            }
        }

        for (Map.Entry<String, String> entry : blocks.entrySet()) {
            String[] coords = entry.getKey().split(",");
            int x = Integer.parseInt(coords[0]);
            int y = Integer.parseInt(coords[1]);
            int z = Integer.parseInt(coords[2]);
            BlockData data = Bukkit.createBlockData(entry.getValue());
            world.getBlockAt(ox + x, oy + y, oz + z).setBlockData(data, false);
        }

        Location s1 = origin.clone().add(spawn1.getX() + 0.5, spawn1.getY(), spawn1.getZ() + 0.5);
        Location s2 = origin.clone().add(spawn2.getX() + 0.5, spawn2.getY(), spawn2.getZ() + 0.5);

        s1.setDirection(s2.toVector().subtract(s1.toVector()));
        s2.setDirection(s1.toVector().subtract(s2.toVector()));

        return new Location[]{s1, s2};
    }

    public void clear(Location origin) {
        World world = origin.getWorld();
        int ox = origin.getBlockX();
        int oy = origin.getBlockY();
        int oz = origin.getBlockZ();
        for (int x = 0; x <= sizeX; x++) {
            for (int y = 0; y <= sizeY; y++) {
                for (int z = 0; z <= sizeZ; z++) {
                    world.getBlockAt(ox + x, oy + y, oz + z).setType(Material.AIR, false);
                }
            }
        }
    }
}
