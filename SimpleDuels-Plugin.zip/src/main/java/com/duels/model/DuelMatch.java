package com.duels.model;

import org.bukkit.Location;

import java.util.UUID;

public class DuelMatch {
    private final UUID player1;
    private final UUID player2;
    private final DuelKit kit;
    private final ArenaMap arenaMap;
    private final Location origin;
    private final int slotIndex;
    private boolean starting = true;

    public DuelMatch(UUID player1, UUID player2, DuelKit kit, ArenaMap arenaMap, Location origin, int slotIndex) {
        this.player1 = player1;
        this.player2 = player2;
        this.kit = kit;
        this.arenaMap = arenaMap;
        this.origin = origin;
        this.slotIndex = slotIndex;
    }

    public UUID getPlayer1() { return player1; }
    public UUID getPlayer2() { return player2; }
    public DuelKit getKit() { return kit; }
    public ArenaMap getArenaMap() { return arenaMap; }
    public Location getOrigin() { return origin; }
    public int getSlotIndex() { return slotIndex; }
    public boolean isStarting() { return starting; }
    public void setStarting(boolean starting) { this.starting = starting; }

    public UUID getOpponent(UUID uuid) {
        return uuid.equals(player1) ? player2 : player1;
    }
}
