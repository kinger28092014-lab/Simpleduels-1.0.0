package com.duels.manager;

import com.duels.DuelsPlugin;
import com.duels.model.ArenaMap;
import com.sk89q.worldedit.EmptyClipboardException;
import com.sk89q.worldedit.LocalSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.Region;
import org.bukkit.Material;
import org.bukkit.block.data.BlockData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MapManager {
    private final DuelsPlugin plugin;
    private final File mapsFolder;
    private final Map<String, ArenaMap> loadedMaps = new HashMap<>();

    public MapManager(DuelsPlugin plugin) {
        this.plugin = plugin;
        this.mapsFolder = new File(plugin.getDataFolder(), "maps");
        if (!mapsFolder.exists()) mapsFolder.mkdirs();
        loadAllMaps();
    }

    public ArenaMap importFromWorldEdit(Player player) {
        LocalSession session = WorldEdit.getInstance().getSessionManager().get(BukkitAdapter.adapt(player));
        Clipboard clipboard;
        try {
            clipboard = session.getClipboard().getClipboard();
        } catch (EmptyClipboardException e) {
            player.sendMessage("§cВаш буфер WorldEdit пуст! Выделите карту (//pos1, //pos2) и напишите //copy.");
            return null;
        }

        Region region = clipboard.getRegion();
        BlockVector3 min = region.getMinimumPoint();
        BlockVector3 max = region.getMaximumPoint();

        Map<String, String> blocks = new HashMap<>();
        Vector spawn1 = null;
        Vector spawn2 = null;

        for (int x = min.x(); x <= max.x(); x++) {
            for (int y = min.y(); y <= max.y(); y++) {
                for (int z = min.z(); z <= max.z(); z++) {
                    BlockData data = BukkitAdapter.adapt(clipboard.getBlock(BlockVector3.at(x, y, z)));
                    if (data.getMaterial() == Material.AIR) continue;

                    int rx = x - min.x();
                    int ry = y - min.y();
                    int rz = z - min.z();

                    if (data.getMaterial() == Material.LIME_WOOL) {
                        spawn1 = new Vector(rx, ry, rz);
                        continue;
                    }
                    if (data.getMaterial() == Material.RED_WOOL) {
                        spawn2 = new Vector(rx, ry, rz);
                        continue;
                    }
                    blocks.put(rx + "," + ry + "," + rz, data.getAsString());
                }
            }
        }

        if (spawn1 == null || spawn2 == null) {
            player.sendMessage("§cНа карте должны быть 1 блок лаймовой шерсти (спавн 1) и 1 блок красной шерсти (спавн 2)!");
            return null;
        }

        String id = "map_" + System.currentTimeMillis();
        ArenaMap map = new ArenaMap(id, max.x() - min.x(), max.y() - min.y(), max.z() - min.z(), blocks, spawn1, spawn2);
        saveMap(map);
        return map;
    }

    private void saveMap(ArenaMap map) {
        loadedMaps.put(map.getId(), map);
        File file = new File(mapsFolder, map.getId() + ".yml");
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("sizeX", map.getSizeX());
        cfg.set("sizeY", map.getSizeY());
        cfg.set("sizeZ", map.getSizeZ());
        cfg.set("spawn1", map.getSpawn1());
        cfg.set("spawn2", map.getSpawn2());
        for (Map.Entry<String, String> entry : map.getBlocks().entrySet()) {
            cfg.set("blocks." + entry.getKey(), entry.getValue());
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadAllMaps() {
        File[] files = mapsFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files == null) return;
        for (File f : files) {
            String id = f.getName().replace(".yml", "");
            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
            int sx = cfg.getInt("sizeX");
            int sy = cfg.getInt("sizeY");
            int sz = cfg.getInt("sizeZ");
            Vector s1 = cfg.getVector("spawn1");
            Vector s2 = cfg.getVector("spawn2");
            Map<String, String> blocks = new HashMap<>();
            ConfigurationSection sec = cfg.getConfigurationSection("blocks");
            if (sec != null) {
                for (String key : sec.getKeys(false)) {
                    blocks.put(key, sec.getString(key));
                }
            }
            if (s1 != null && s2 != null) {
                loadedMaps.put(id, new ArenaMap(id, sx, sy, sz, blocks, s1, s2));
            }
        }
    }

    public ArenaMap getMap(String id) { return loadedMaps.get(id); }
}
