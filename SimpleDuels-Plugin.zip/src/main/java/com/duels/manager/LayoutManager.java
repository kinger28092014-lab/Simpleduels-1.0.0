package com.duels.manager;

import com.duels.DuelsPlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class LayoutManager {
    private final File file;
    private final Map<UUID, Map<String, ItemStack[]>> layouts = new HashMap<>();

    public LayoutManager(DuelsPlugin plugin) {
        this.file = new File(plugin.getDataFolder(), "layouts.yml");
        loadLayouts();
    }

    public void setLayout(UUID uuid, String kitId, ItemStack[] contents) {
        layouts.computeIfAbsent(uuid, k -> new HashMap<>()).put(kitId, contents);
        saveLayouts();
    }

    public ItemStack[] getLayout(UUID uuid, String kitId) {
        Map<String, ItemStack[]> playerLayouts = layouts.get(uuid);
        return playerLayouts != null ? playerLayouts.get(kitId) : null;
    }

    public void saveLayouts() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, ItemStack[]>> entry : layouts.entrySet()) {
            String uuidStr = entry.getKey().toString();
            for (Map.Entry<String, ItemStack[]> kitEntry : entry.getValue().entrySet()) {
                cfg.set(uuidStr + "." + kitEntry.getKey(), kitEntry.getValue());
            }
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private void loadLayouts() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        for (String uuidStr : cfg.getKeys(false)) {
            UUID uuid = UUID.fromString(uuidStr);
            ConfigurationSection sec = cfg.getConfigurationSection(uuidStr);
            if (sec == null) continue;
            Map<String, ItemStack[]> map = new HashMap<>();
            for (String kitId : sec.getKeys(false)) {
                List<ItemStack> list = (List<ItemStack>) sec.getList(kitId);
                if (list != null) {
                    map.put(kitId, list.toArray(new ItemStack[36]));
                }
            }
            layouts.put(uuid, map);
        }
    }
}
