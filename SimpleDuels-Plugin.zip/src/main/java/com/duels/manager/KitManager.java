package com.duels.manager;

import com.duels.DuelsPlugin;
import com.duels.model.DuelKit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class KitManager {
    private final DuelsPlugin plugin;
    private final File file;
    private final Map<String, DuelKit> kits = new LinkedHashMap<>();

    public KitManager(DuelsPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "kits.yml");
        loadKits();
    }

    public void addKit(DuelKit kit) {
        kits.put(kit.getId(), kit);
        saveKits();
    }

    public void removeKit(String id) {
        kits.remove(id);
        saveKits();
    }

    public DuelKit getKit(String id) { return kits.get(id); }
    public Collection<DuelKit> getAllKits() { return kits.values(); }

    public void saveKits() {
        YamlConfiguration cfg = new YamlConfiguration();
        for (DuelKit kit : kits.values()) {
            String path = "kits." + kit.getId();
            cfg.set(path + ".displayName", kit.getDisplayName());
            cfg.set(path + ".icon", kit.getIcon().name());
            cfg.set(path + ".contents", kit.getContents());
            cfg.set(path + ".armor", kit.getArmor());
            cfg.set(path + ".offhand", kit.getOffhand());
            cfg.set(path + ".maps", kit.getMapIds());
        }
        try {
            cfg.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    private void loadKits() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = cfg.getConfigurationSection("kits");
        if (sec == null) return;

        for (String id : sec.getKeys(false)) {
            String path = "kits." + id;
            String name = cfg.getString(path + ".displayName", id);
            Material icon = Material.matchMaterial(cfg.getString(path + ".icon", "DIAMOND_SWORD"));
            List<ItemStack> contentsList = (List<ItemStack>) cfg.getList(path + ".contents");
            List<ItemStack> armorList = (List<ItemStack>) cfg.getList(path + ".armor");
            ItemStack offhand = cfg.getItemStack(path + ".offhand");

            ItemStack[] contents = contentsList != null ? contentsList.toArray(new ItemStack[36]) : new ItemStack[36];
            ItemStack[] armor = armorList != null ? armorList.toArray(new ItemStack[4]) : new ItemStack[4];

            DuelKit kit = new DuelKit(id, name, icon, contents, armor, offhand);
            kit.getMapIds().addAll(cfg.getStringList(path + ".maps"));
            kits.put(id, kit);
        }
    }
}
