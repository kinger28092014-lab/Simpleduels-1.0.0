package com.duels.manager;

import com.duels.DuelsPlugin;
import com.duels.model.ArenaMap;
import com.duels.model.DuelKit;
import com.duels.model.DuelMatch;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class DuelManager {
    private final DuelsPlugin plugin;
    private final Map<String, Queue<UUID>> queues = new HashMap<>();
    private final Map<UUID, DuelMatch> activeMatches = new HashMap<>();
    private final Set<Integer> usedSlots = new HashSet<>();
    private final Random random = new Random();

    public DuelManager(DuelsPlugin plugin) {
        this.plugin = plugin;
    }

    private String getSwordNameRaw() {
        return plugin.getConfig().getString("sword-name", "&4Дуэль");
    }

    public void giveLobbyItems(Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        player.setGameMode(GameMode.ADVENTURE);

        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.displayName(LegacyComponentSerializer.legacyAmpersand().deserialize(getSwordNameRaw()));
        meta.setUnbreakable(true);
        sword.setItemMeta(meta);

        player.getInventory().setItem(0, sword);
    }

    public boolean isDuelSword(ItemStack item) {
        if (item == null || item.getType() != Material.NETHERITE_SWORD || !item.hasItemMeta()) return false;
        Component name = item.getItemMeta().displayName();
        if (name == null) return false;
        return LegacyComponentSerializer.legacyAmpersand().serialize(name).equals(getSwordNameRaw());
    }

    public void joinQueue(Player player, DuelKit kit) {
        if (isInMatch(player.getUniqueId())) {
            player.sendMessage("§cВы уже в дуэли!");
            return;
        }
        if (kit.getMapIds().isEmpty()) {
            player.sendMessage("§cДля этого кита ещё не добавлено ни одной карты!");
            return;
        }

        leaveQueue(player);

        Queue<UUID> queue = queues.computeIfAbsent(kit.getId(), k -> new LinkedList<>());
        if (!queue.isEmpty()) {
            UUID opponentId = queue.poll();
            Player opponent = Bukkit.getPlayer(opponentId);
            if (opponent != null && opponent.isOnline()) {
                startMatch(opponent, player, kit);
                return;
            }
        }

        queue.add(player.getUniqueId());
        player.sendMessage("§aВы встали в очередь на кит §e" + kit.getDisplayName() + "§a. Ожидаем соперника...");
    }

    public void leaveQueue(Player player) {
        for (Queue<UUID> q : queues.values()) {
            q.remove(player.getUniqueId());
        }
    }

    private void startMatch(Player p1, Player p2, DuelKit kit) {
        String mapId = kit.getMapIds().get(random.nextInt(kit.getMapIds().size()));
        ArenaMap map = plugin.getMapManager().getMap(mapId);
        if (map == null) {
            p1.sendMessage("§cОшибка загрузки карты!");
            p2.sendMessage("§cОшибка загрузки карты!");
            return;
        }

        int slot = allocateSlot();
        World world = plugin.getLobbyLocation() != null ? plugin.getLobbyLocation().getWorld() : Bukkit.getWorlds().get(0);
        Location origin = new Location(world, 10000 + (slot * 500), 100, 10000);
        Location[] spawns = map.paste(origin);

        DuelMatch match = new DuelMatch(p1.getUniqueId(), p2.getUniqueId(), kit, map, origin, slot);
        activeMatches.put(p1.getUniqueId(), match);
        activeMatches.put(p2.getUniqueId(), match);

        preparePlayerForMatch(p1, kit, spawns[0]);
        preparePlayerForMatch(p2, kit, spawns[1]);

        new BukkitRunnable() {
            int countdown = 3;
            @Override
            public void run() {
                if (!activeMatches.containsKey(p1.getUniqueId())) {
                    cancel();
                    return;
                }
                if (countdown > 0) {
                    String msg = "§eБой начнётся через §c" + countdown + "...";
                    p1.sendMessage(msg);
                    p2.sendMessage(msg);
                    p1.playSound(p1.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                    p2.playSound(p2.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
                    countdown--;
                } else {
                    match.setStarting(false);
                    p1.sendMessage("§aБой начался! Удачи!");
                    p2.sendMessage("§aБой начался! Удачи!");
                    p1.playSound(p1.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.2f);
                    p2.playSound(p2.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.7f, 1.2f);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    private void preparePlayerForMatch(Player player, DuelKit kit, Location spawn) {
        player.teleport(spawn);
        player.setGameMode(GameMode.SURVIVAL);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.getInventory().clear();

        ItemStack[] layout = plugin.getLayoutManager().getLayout(player.getUniqueId(), kit.getId());
        ItemStack[] contents = layout != null ? layout : kit.getContents();

        player.getInventory().setContents(cloneArray(contents));
        player.getInventory().setArmorContents(cloneArray(kit.getArmor()));
        player.getInventory().setItemInOffHand(kit.getOffhand() != null ? kit.getOffhand().clone() : null);
    }

    public void endMatch(DuelMatch match, UUID winnerId) {
        if (!activeMatches.containsKey(match.getPlayer1())) return;

        activeMatches.remove(match.getPlayer1());
        activeMatches.remove(match.getPlayer2());

        Player winner = Bukkit.getPlayer(winnerId);
        Player loser = Bukkit.getPlayer(match.getOpponent(winnerId));

        String winName = winner != null ? winner.getName() : "Игрок";
        String loseName = loser != null ? loser.getName() : "Игрок";
        String hp = winner != null ? String.format("%.1f", winner.getHealth()) : "0";

        String result = "§6[Дуэль] §a" + winName + " §7(" + hp + "❤) победил §c" + loseName + " §7на ките §e" + match.getKit().getDisplayName();
        if (winner != null) winner.sendMessage(result);
        if (loser != null) loser.sendMessage(result);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (winner != null && winner.isOnline()) sendToLobby(winner);
            if (loser != null && loser.isOnline()) sendToLobby(loser);
            match.getArenaMap().clear(match.getOrigin());
            usedSlots.remove(match.getSlotIndex());
        }, 40L);
    }

    public void sendToLobby(Player player) {
        if (plugin.getLobbyLocation() != null) {
            player.teleport(plugin.getLobbyLocation());
        }
        giveLobbyItems(player);
    }

    public void shutdownAll() {
        Set<DuelMatch> unique = new HashSet<>(activeMatches.values());
        for (DuelMatch m : unique) {
            m.getArenaMap().clear(m.getOrigin());
        }
        activeMatches.clear();
        queues.clear();
        usedSlots.clear();
    }

    public int getFightingCount(String kitId) {
        int count = 0;
        for (DuelMatch m : activeMatches.values()) {
            if (m.getKit().getId().equals(kitId)) count++;
        }
        return count;
    }

    public int getWaitingCount(String kitId) {
        Queue<UUID> q = queues.get(kitId);
        return q != null ? q.size() : 0;
    }

    public boolean isInMatch(UUID uuid) { return activeMatches.containsKey(uuid); }
    public DuelMatch getMatch(UUID uuid) { return activeMatches.get(uuid); }

    private int allocateSlot() {
        int i = 0;
        while (usedSlots.contains(i)) i++;
        usedSlots.add(i);
        return i;
    }

    public static ItemStack[] cloneArray(ItemStack[] source) {
        if (source == null) return new ItemStack[0];
        ItemStack[] copy = new ItemStack[source.length];
        for (int i = 0; i < source.length; i++) {
            copy[i] = source[i] != null ? source[i].clone() : null;
        }
        return copy;
    }
}
