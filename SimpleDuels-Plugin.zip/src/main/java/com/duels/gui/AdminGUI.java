package com.duels.gui;

import com.duels.DuelsPlugin;
import com.duels.model.DuelKit;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class AdminGUI {
    public static final String MAIN_TITLE = "§4Админ-меню китов";
    public static final String EDIT_PREFIX = "§4Редактирование: ";

    public static void openMain(DuelsPlugin plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, Component.text(MAIN_TITLE));
        NamespacedKey key = new NamespacedKey(plugin, "admin_kit_id");

        int slot = 0;
        for (DuelKit kit : plugin.getKitManager().getAllKits()) {
            if (slot >= 45) break;
            ItemStack item = new ItemStack(kit.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text("§e" + kit.getDisplayName()));
            meta.lore(List.of(
                    Component.text("§7ID: §f" + kit.getId()),
                    Component.text("§7Карт: §b" + kit.getMapIds().size()),
                    Component.text("§aНажмите для редактирования")
            ));
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, kit.getId());
            item.setItemMeta(meta);
            inv.setItem(slot++, item);
        }

        ItemStack create = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta cm = create.getItemMeta();
        cm.displayName(Component.text("§a+ Создать новый кит"));
        cm.lore(List.of(
                Component.text("§7Вещи, броня и offhand возьмутся"),
                Component.text("§7из вашего текущего инвентаря.")
        ));
        create.setItemMeta(cm);
        inv.setItem(49, create);

        player.openInventory(inv);
    }

    public static void openEdit(DuelsPlugin plugin, Player player, DuelKit kit) {
        Inventory inv = Bukkit.createInventory(null, 27, Component.text(EDIT_PREFIX + kit.getId()));

        // Смена иконки
        ItemStack iconBtn = new ItemStack(kit.getIcon());
        ItemMeta im = iconBtn.getItemMeta();
        im.displayName(Component.text("§eИзменить иконку кита"));
        im.lore(List.of(
                Component.text("§7Возьмите нужный предмет в руку"),
                Component.text("§7и нажмите сюда, чтобы сменить иконку.")
        ));
        iconBtn.setItemMeta(im);
        inv.setItem(10, iconBtn);

        // Добавить карту из WorldEdit
        ItemStack mapBtn = new ItemStack(Material.GRASS_BLOCK);
        ItemMeta mm = mapBtn.getItemMeta();
        mm.displayName(Component.text("§bВставить карту из WorldEdit"));
        mm.lore(List.of(
                Component.text("§7Скопируйте карту через //copy"),
                Component.text("§7(Лаймовая шерсть = спавн 1, Красная = спавн 2)"),
                Component.text("§7Сейчас карт: §e" + kit.getMapIds().size())
        ));
        mapBtn.setItemMeta(mm);
        inv.setItem(12, mapBtn);

        // Обновить вещи кита
        ItemStack invBtn = new ItemStack(Material.CHEST);
        ItemMeta ivm = invBtn.getItemMeta();
        ivm.displayName(Component.text("§aОбновить вещи из инвентаря"));
        ivm.lore(List.of(Component.text("§7Перезапишет предметы, броню и offhand кита.")));
        invBtn.setItemMeta(ivm);
        inv.setItem(14, invBtn);

        // Удалить кит
        ItemStack delBtn = new ItemStack(Material.BARRIER);
        ItemMeta dm = delBtn.getItemMeta();
        dm.displayName(Component.text("§cУдалить кит"));
        delBtn.setItemMeta(dm);
        inv.setItem(16, delBtn);

        // Назад
        ItemStack backBtn = new ItemStack(Material.ARROW);
        ItemMeta bm = backBtn.getItemMeta();
        bm.displayName(Component.text("§7← Назад"));
        backBtn.setItemMeta(bm);
        inv.setItem(22, backBtn);

        player.openInventory(inv);
    }
}
