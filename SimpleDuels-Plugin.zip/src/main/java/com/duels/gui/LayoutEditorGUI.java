package com.duels.gui;

import com.duels.DuelsPlugin;
import com.duels.manager.DuelManager;
import com.duels.model.DuelKit;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class LayoutEditorGUI {
    public static final String PREFIX = "§8Раскладка: ";

    public static void open(DuelsPlugin plugin, Player player, DuelKit kit) {
        Inventory inv = Bukkit.createInventory(null, 45, Component.text(PREFIX + kit.getId()));

        ItemStack[] saved = plugin.getLayoutManager().getLayout(player.getUniqueId(), kit.getId());
        ItemStack[] contents = DuelManager.cloneArray(saved != null ? saved : kit.getContents());

        for (int i = 0; i < 36 && i < contents.length; i++) {
            inv.setItem(i, contents[i]);
        }

        // Разделительная панель на слотах 36-44
        ItemStack glass = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta gm = glass.getItemMeta();
        gm.displayName(Component.text("§7Переставляйте предметы выше"));
        glass.setItemMeta(gm);
        for (int i = 36; i < 45; i++) {
            inv.setItem(i, glass);
        }

        ItemStack save = new ItemStack(Material.LIME_WOOL);
        ItemMeta sm = save.getItemMeta();
        sm.displayName(Component.text("§aСохранить раскладку"));
        save.setItemMeta(sm);
        inv.setItem(40, save);

        player.openInventory(inv);
    }
}
