package com.duels.gui;

import com.duels.DuelsPlugin;
import com.duels.model.DuelKit;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

public class DuelGUI {
    public static final String TITLE = "§8Выбор кита для дуэли";

    public static void open(DuelsPlugin plugin, Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, Component.text(TITLE));
        NamespacedKey key = new NamespacedKey(plugin, "kit_id");

        int slot = 0;
        for (DuelKit kit : plugin.getKitManager().getAllKits()) {
            if (slot >= 54) break;
            ItemStack item = new ItemStack(kit.getIcon());
            ItemMeta meta = item.getItemMeta();
            meta.displayName(Component.text("§e" + kit.getDisplayName()));

            int fighting = plugin.getDuelManager().getFightingCount(kit.getId());
            int waiting = plugin.getDuelManager().getWaitingCount(kit.getId());

            meta.lore(List.of(
                    Component.text("§7В бою: §a" + fighting),
                    Component.text("§7В очереди: §e" + waiting),
                    Component.text("§7Карт привязано: §b" + kit.getMapIds().size()),
                    Component.text(""),
                    Component.text("§aЛКМ §7— Встать в очередь"),
                    Component.text("§eПКМ §7— Изменить раскладку вещей")
            ));
            meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, kit.getId());
            item.setItemMeta(meta);
            inv.setItem(slot++, item);
        }

        player.openInventory(inv);
    }
}
