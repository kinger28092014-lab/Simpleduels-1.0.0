package com.duels;

import com.duels.command.AdminCommand;
import com.duels.command.DuelCommand;
import com.duels.listener.DuelListener;
import com.duels.listener.GuiListener;
import com.duels.listener.LobbyListener;
import com.duels.manager.DuelManager;
import com.duels.manager.KitManager;
import com.duels.manager.LayoutManager;
import com.duels.manager.MapManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.java.JavaPlugin;

public class DuelsPlugin extends JavaPlugin {

    private MapManager mapManager;
    private KitManager kitManager;
    private LayoutManager layoutManager;
    private DuelManager duelManager;
    private Location lobbyLocation;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadLobby();

        this.mapManager = new MapManager(this);
        this.kitManager = new KitManager(this);
        this.layoutManager = new LayoutManager(this);
        this.duelManager = new DuelManager(this);

        getCommand("duel").setExecutor(new DuelCommand(this));
        getCommand("dueladmin").setExecutor(new AdminCommand(this));

        Bukkit.getPluginManager().registerEvents(new LobbyListener(this), this);
        Bukkit.getPluginManager().registerEvents(new DuelListener(this), this);
        Bukkit.getPluginManager().registerEvents(new GuiListener(this), this);

        getLogger().info("SimpleDuels успешно запущен!");
    }

    @Override
    public void onDisable() {
        if (duelManager != null) {
            duelManager.shutdownAll();
        }
        if (kitManager != null) {
            kitManager.saveKits();
        }
        if (layoutManager != null) {
            layoutManager.saveLayouts();
        }
    }

    public void setLobbyLocation(Location loc) {
        this.lobbyLocation = loc;
        getConfig().set("lobby.world", loc.getWorld().getName());
        getConfig().set("lobby.x", loc.getX());
        getConfig().set("lobby.y", loc.getY());
        getConfig().set("lobby.z", loc.getZ());
        getConfig().set("lobby.yaw", loc.getYaw());
        getConfig().set("lobby.pitch", loc.getPitch());
        saveConfig();
    }

    private void loadLobby() {
        if (getConfig().contains("lobby.world")) {
            World w = Bukkit.getWorld(getConfig().getString("lobby.world"));
            if (w != null) {
                this.lobbyLocation = new Location(
                        w,
                        getConfig().getDouble("lobby.x"),
                        getConfig().getDouble("lobby.y"),
                        getConfig().getDouble("lobby.z"),
                        (float) getConfig().getDouble("lobby.yaw"),
                        (float) getConfig().getDouble("lobby.pitch")
                );
            }
        }
    }

    public Location getLobbyLocation() { return lobbyLocation; }
    public MapManager getMapManager() { return mapManager; }
    public KitManager getKitManager() { return kitManager; }
    public LayoutManager getLayoutManager() { return layoutManager; }
    public DuelManager getDuelManager() { return duelManager; }
}
